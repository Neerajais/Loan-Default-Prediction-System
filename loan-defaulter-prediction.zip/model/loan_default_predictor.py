import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix
from sklearn.metrics import classification_report, roc_curve
import joblib
import os

class LoanDefaultPredictor:
    def __init__(self):
        self.model = None
        self.preprocessor = None
        self.feature_names = None
        self.categorical_features = ['home_ownership', 'purpose', 'previous_defaults']
        self.numerical_features = ['income', 'credit_score', 'age', 'loan_amount', 'loan_term', 
                                  'employment_years', 'debt_to_income']
        
    def preprocess_data(self, data):
        """Preprocess the data with feature engineering and transformations"""
        # Create a copy to avoid modifying the original data
        df = data.copy()
        
        # Feature engineering
        if 'income' in df.columns and 'loan_amount' in df.columns:
            df['loan_to_income_ratio'] = df['loan_amount'] / df['income']
            self.numerical_features.append('loan_to_income_ratio')
        
        # Create preprocessor
        numerical_transformer = Pipeline(steps=[
            ('imputer', SimpleImputer(strategy='median')),
            ('scaler', StandardScaler())
        ])
        
        categorical_transformer = Pipeline(steps=[
            ('imputer', SimpleImputer(strategy='most_frequent')),
            ('onehot', OneHotEncoder(handle_unknown='ignore'))
        ])
        
        self.preprocessor = ColumnTransformer(
            transformers=[
                ('num', numerical_transformer, self.numerical_features),
                ('cat', categorical_transformer, self.categorical_features)
            ])
        
        return df
    
    def train(self, data, target='default'):
        """Train the loan default prediction model"""
        print("Starting model training...")
        
        # Preprocess data
        df = self.preprocess_data(data)
        self.feature_names = self.numerical_features + self.categorical_features
        
        # Split data
        X = df[self.feature_names]
        y = df[target]
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        print(f"Training data shape: {X_train.shape}")
        
        # Define models to try
        models = {
            'GradientBoosting': GradientBoostingClassifier(random_state=42),
            'RandomForest': RandomForestClassifier(random_state=42),
            'LogisticRegression': LogisticRegression(random_state=42, max_iter=1000)
        }
        
        # Parameters for GridSearch
        params = {
            'GradientBoosting': {
                'classifier__n_estimators': [100, 200],
                'classifier__learning_rate': [0.05, 0.1],
                'classifier__max_depth': [3, 5]
            },
            'RandomForest': {
                'classifier__n_estimators': [100, 200],
                'classifier__max_depth': [None, 10, 20],
                'classifier__min_samples_split': [2, 5]
            },
            'LogisticRegression': {
                'classifier__C': [0.1, 1.0, 10.0],
                'classifier__penalty': ['l2']
            }
        }
        
        best_score = 0
        best_model_name = None
        results = {}
        
        # Train and evaluate each model
        for model_name, model in models.items():
            print(f"\nTraining {model_name}...")
            
            # Create pipeline with preprocessor and classifier
            pipeline = Pipeline(steps=[
                ('preprocessor', self.preprocessor),
                ('classifier', model)
            ])
            
            # Grid search for hyperparameter tuning
            grid_search = GridSearchCV(
                pipeline,
                params[model_name],
                cv=5,
                scoring='accuracy',
                n_jobs=-1
            )
            
            grid_search.fit(X_train, y_train)
            
            # Get best model
            best_pipeline = grid_search.best_estimator_
            y_pred = best_pipeline.predict(X_test)
            
            # Calculate metrics
            accuracy = accuracy_score(y_test, y_pred)
            precision = precision_score(y_test, y_pred)
            recall = recall_score(y_test, y_pred)
            f1 = f1_score(y_test, y_pred)
            roc_auc = roc_auc_score(y_test, y_pred)
            
            print(f"{model_name} Results:")
            print(f"  Accuracy: {accuracy:.4f}")
            print(f"  Precision: {precision:.4f}")
            print(f"  Recall: {recall:.4f}")
            print(f"  F1 Score: {f1:.4f}")
            print(f"  ROC AUC: {roc_auc:.4f}")
            print(f"  Best Parameters: {grid_search.best_params_}")
            
            results[model_name] = {
                'pipeline': best_pipeline,
                'accuracy': accuracy,
                'precision': precision,
                'recall': recall,
                'f1': f1,
                'roc_auc': roc_auc,
                'best_params': grid_search.best_params_
            }
            
            # Track best model
            if accuracy > best_score:
                best_score = accuracy
                best_model_name = model_name
        
        # Select best model
        print(f"\nBest model: {best_model_name} with accuracy {best_score:.4f}")
        self.model = results[best_model_name]['pipeline']
        
        # Detailed evaluation of best model
        y_pred = self.model.predict(X_test)
        print("\nDetailed evaluation of best model:")
        print(classification_report(y_test, y_pred))
        
        # Plot confusion matrix
        cm = confusion_matrix(y_test, y_pred)
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
        plt.title(f'Confusion Matrix - {best_model_name}')
        plt.ylabel('Actual')
        plt.xlabel('Predicted')
        plt.show()
        
        # Plot ROC curve
        y_prob = self.model.predict_proba(X_test)[:, 1]
        fpr, tpr, _ = roc_curve(y_test, y_prob)
        plt.figure(figsize=(8, 6))
        plt.plot(fpr, tpr, label=f'ROC Curve (AUC = {roc_auc:.4f})')
        plt.plot([0, 1], [0, 1], 'k--')
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('ROC Curve')
        plt.legend(loc='lower right')
        plt.show()
        
        # Feature importance (if applicable)
        if best_model_name in ['GradientBoosting', 'RandomForest']:
            self._plot_feature_importance(best_model_name)
        
        return results
    
    def _plot_feature_importance(self, model_name):
        """Plot feature importance for tree-based models"""
        if model_name in ['GradientBoosting', 'RandomForest']:
            # Get feature names after preprocessing
            preprocessor = self.model.named_steps['preprocessor']
            model = self.model.named_steps['classifier']
            
            # Get feature names after one-hot encoding
            cat_features = preprocessor.transformers_[1][2]
            cat_transformer = preprocessor.transformers_[1][1]
            cat_encoder = cat_transformer.named_steps['onehot']
            
            # Get all feature names
            feature_names = self.numerical_features.copy()
            
            # Add encoded categorical feature names
            if hasattr(cat_encoder, 'get_feature_names_out'):
                encoded_features = cat_encoder.get_feature_names_out(cat_features)
                feature_names.extend(encoded_features)
            
            # Get feature importances
            importances = model.feature_importances_
            
            # Sort features by importance
            indices = np.argsort(importances)[::-1]
            
            # Plot feature importance
            plt.figure(figsize=(12, 8))
            plt.title(f'Feature Importance - {model_name}')
            plt.bar(range(len(indices)), importances[indices], align='center')
            plt.xticks(range(len(indices)), [feature_names[i] for i in indices], rotation=90)
            plt.tight_layout()
            plt.show()
    
    def predict(self, data):
        """Make predictions with the trained model"""
        if self.model is None:
            raise ValueError("Model has not been trained yet")
        
        # Ensure data has the expected features
        missing_features = [f for f in self.feature_names if f not in data.columns]
        if missing_features:
            raise ValueError(f"Missing features in input data: {missing_features}")
        
        # Make prediction
        X = data[self.feature_names]
        predictions = self.model.predict(X)
        probabilities = self.model.predict_proba(X)[:, 1]
        
        return predictions, probabilities
    
    def save_model(self, filepath='model/loan_default_model.pkl'):
        """Save the trained model to disk"""
        if self.model is None:
            raise ValueError("No model to save")
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        
        # Save model
        joblib.dump(self.model, filepath)
        print(f"Model saved to {filepath}")
    
    def load_model(self, filepath='model/loan_default_model.pkl'):
        """Load a trained model from disk"""
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"Model file not found: {filepath}")
        
        self.model = joblib.load(filepath)
        print(f"Model loaded from {filepath}")

# Example usage
if __name__ == "__main__":
    # Generate synthetic data for demonstration
    np.random.seed(42)
    n_samples = 10000
    
    # Generate synthetic features
    income = np.random.normal(60000, 20000, n_samples)
    credit_score = np.random.normal(700, 100, n_samples)
    age = np.random.normal(40, 10, n_samples)
    loan_amount = np.random.normal(25000, 15000, n_samples)
    loan_term = np.random.choice([12, 24, 36, 48, 60, 72], n_samples)
    employment_years = np.random.gamma(5, 1, n_samples)
    debt_to_income = np.random.beta(2, 5, n_samples) * 100
    
    # Generate categorical features
    home_ownership = np.random.choice(['OWN', 'MORTGAGE', 'RENT', 'OTHER'], n_samples, p=[0.3, 0.4, 0.25, 0.05])
    purpose = np.random.choice(['PERSONAL', 'EDUCATION', 'MEDICAL', 'VENTURE', 'HOMEIMPROVEMENT', 'DEBTCONSOLIDATION', 'OTHER'], 
                              n_samples, p=[0.2, 0.1, 0.1, 0.05, 0.15, 0.3, 0.1])
    previous_defaults = np.random.choice(['YES', 'NO'], n_samples, p=[0.15, 0.85])
    
    # Create synthetic target based on features
    # Higher probability of default if:
    # - Low credit score
    # - High debt-to-income ratio
    # - Previous defaults
    # - High loan amount relative to income
    default_prob = (
        0.5 * (1 - (credit_score - 300) / 550) +  # Credit score factor
        0.2 * (debt_to_income / 100) +            # Debt-to-income factor
        0.2 * (previous_defaults == 'YES') +      # Previous defaults factor
        0.1 * (loan_amount / income)              # Loan-to-income factor
    )
    
    # Add some noise
    default_prob = np.clip(default_prob + np.random.normal(0, 0.1, n_samples), 0, 1)
    
    # Generate binary default outcome
    default = (np.random.random(n_samples) < default_prob).astype(int)
    
    # Create DataFrame
    data = pd.DataFrame({
        'income': income,
        'credit_score': credit_score,
        'age': age,
        'loan_amount': loan_amount,
        'loan_term': loan_term,
        'employment_years': employment_years,
        'debt_to_income': debt_to_income,
        'home_ownership': home_ownership,
        'purpose': purpose,
        'previous_defaults': previous_defaults,
        'default': default
    })
    
    # Clean up data (remove negative values, etc.)
    data['income'] = data['income'].clip(lower=10000)
    data['credit_score'] = data['credit_score'].clip(lower=300, upper=850)
    data['age'] = data['age'].clip(lower=18, upper=100)
    data['loan_amount'] = data['loan_amount'].clip(lower=1000)
    data['employment_years'] = data['employment_years'].clip(lower=0)
    
    # Print data summary
    print("Synthetic data summary:")
    print(data.describe())
    print("\nDefault rate:", data['default'].mean())
    
    # Train model
    predictor = LoanDefaultPredictor()
    results = predictor.train(data)
    
    # Save model
    predictor.save_model()
    
    # Example prediction
    new_data = pd.DataFrame({
        'income': [75000],
        'credit_score': [720],
        'age': [35],
        'loan_amount': [25000],
        'loan_term': [36],
        'employment_years': [5],
        'debt_to_income': [30],
        'home_ownership': ['OWN'],
        'purpose': ['PERSONAL'],
        'previous_defaults': ['NO']
    })
    
    predictions, probabilities = predictor.predict(new_data)
    print("\nExample prediction:")
    print(f"Default prediction: {predictions[0]} (1 = default, 0 = no default)")
    print(f"Default probability: {probabilities[0]:.4f}")
