"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from "recharts"
import {
  Download,
  Filter,
  RefreshCw,
  TrendingDown,
  TrendingUp,
  DollarSign,
  Users,
  AlertTriangle,
  CheckCircle2,
} from "lucide-react"

// Mock data for charts
const monthlyDefaultData = [
  { name: "Jan", defaults: 12, approvals: 120 },
  { name: "Feb", defaults: 19, approvals: 132 },
  { name: "Mar", defaults: 15, approvals: 99 },
  { name: "Apr", defaults: 8, approvals: 85 },
  { name: "May", defaults: 10, approvals: 91 },
  { name: "Jun", defaults: 14, approvals: 105 },
  { name: "Jul", defaults: 12, approvals: 118 },
  { name: "Aug", defaults: 18, approvals: 110 },
  { name: "Sep", defaults: 15, approvals: 113 },
  { name: "Oct", defaults: 11, approvals: 129 },
  { name: "Nov", defaults: 9, approvals: 138 },
  { name: "Dec", defaults: 7, approvals: 142 },
]

const riskDistributionData = [
  { name: "Low Risk", value: 65 },
  { name: "Medium Risk", value: 25 },
  { name: "High Risk", value: 10 },
]

const COLORS = ["#4ade80", "#facc15", "#f87171"]

const featureImportanceData = [
  { name: "Credit Score", importance: 0.28 },
  { name: "Debt-to-Income", importance: 0.22 },
  { name: "Income", importance: 0.18 },
  { name: "Loan Amount", importance: 0.12 },
  { name: "Previous Defaults", importance: 0.1 },
  { name: "Employment Years", importance: 0.06 },
  { name: "Loan Purpose", importance: 0.04 },
]

const modelPerformanceData = [
  { name: "Jan", accuracy: 0.78, precision: 0.76, recall: 0.72 },
  { name: "Feb", accuracy: 0.79, precision: 0.77, recall: 0.73 },
  { name: "Mar", accuracy: 0.79, precision: 0.78, recall: 0.74 },
  { name: "Apr", accuracy: 0.8, precision: 0.79, recall: 0.75 },
  { name: "May", accuracy: 0.81, precision: 0.8, recall: 0.76 },
  { name: "Jun", accuracy: 0.81, precision: 0.8, recall: 0.77 },
  { name: "Jul", accuracy: 0.82, precision: 0.81, recall: 0.78 },
  { name: "Aug", accuracy: 0.82, precision: 0.81, recall: 0.79 },
  { name: "Sep", accuracy: 0.83, precision: 0.82, recall: 0.8 },
  { name: "Oct", accuracy: 0.83, precision: 0.82, recall: 0.8 },
  { name: "Nov", accuracy: 0.84, precision: 0.83, recall: 0.81 },
  { name: "Dec", accuracy: 0.85, precision: 0.84, recall: 0.82 },
]

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold">Loan Default Analytics Dashboard</h1>
          <p className="text-gray-500">Monitor model performance and loan default trends</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button variant="outline" size="sm">
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="model">Model Performance</TabsTrigger>
          <TabsTrigger value="features">Feature Analysis</TabsTrigger>
          <TabsTrigger value="predictions">Predictions</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Default Rate</CardTitle>
                <TrendingDown className="h-4 w-4 text-red-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">8.2%</div>
                <p className="text-xs text-green-500 flex items-center">
                  <TrendingDown className="h-3 w-3 mr-1" />
                  10% decrease from last year
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Savings</CardTitle>
                <DollarSign className="h-4 w-4 text-green-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$1.2M</div>
                <p className="text-xs text-green-500 flex items-center">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  15% increase from last year
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Model Accuracy</CardTitle>
                <TrendingUp className="h-4 w-4 text-green-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">80%</div>
                <p className="text-xs text-green-500 flex items-center">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  2% improvement from last version
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Loans</CardTitle>
                <Users className="h-4 w-4 text-blue-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">1,482</div>
                <p className="text-xs text-green-500 flex items-center">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  8% increase from last month
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Monthly Default Trends</CardTitle>
                <CardDescription>Number of defaults vs. approvals over the past year</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={monthlyDefaultData}
                      margin={{
                        top: 20,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="approvals" fill="#3b82f6" name="Approvals" />
                      <Bar dataKey="defaults" fill="#ef4444" name="Defaults" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Risk Distribution</CardTitle>
                <CardDescription>Current loan portfolio by risk category</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={riskDistributionData}
                        cx="50%"
                        cy="50%"
                        labelLine={true}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {riskDistributionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>High Risk Alerts</CardTitle>
              <CardDescription>Recent loan applications flagged as high risk</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4">Application ID</th>
                      <th className="text-left py-3 px-4">Date</th>
                      <th className="text-left py-3 px-4">Amount</th>
                      <th className="text-left py-3 px-4">Risk Score</th>
                      <th className="text-left py-3 px-4">Key Factors</th>
                      <th className="text-left py-3 px-4">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b">
                      <td className="py-3 px-4">APP-7829</td>
                      <td className="py-3 px-4">May 18, 2025</td>
                      <td className="py-3 px-4">$35,000</td>
                      <td className="py-3 px-4">
                        <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">High (87%)</span>
                      </td>
                      <td className="py-3 px-4">Low credit score, Previous defaults</td>
                      <td className="py-3 px-4">
                        <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs">Review</span>
                      </td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-3 px-4">APP-7830</td>
                      <td className="py-3 px-4">May 17, 2025</td>
                      <td className="py-3 px-4">$50,000</td>
                      <td className="py-3 px-4">
                        <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">High (92%)</span>
                      </td>
                      <td className="py-3 px-4">High debt-to-income ratio, Short employment</td>
                      <td className="py-3 px-4">
                        <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">Rejected</span>
                      </td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-3 px-4">APP-7835</td>
                      <td className="py-3 px-4">May 16, 2025</td>
                      <td className="py-3 px-4">$25,000</td>
                      <td className="py-3 px-4">
                        <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">High (81%)</span>
                      </td>
                      <td className="py-3 px-4">Previous defaults, Low income</td>
                      <td className="py-3 px-4">
                        <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs">Review</span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="model" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Accuracy</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">80%</div>
                <p className="text-xs text-green-500 flex items-center">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  2% improvement
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Precision</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">84%</div>
                <p className="text-xs text-green-500 flex items-center">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  3% improvement
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Recall</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">82%</div>
                <p className="text-xs text-green-500 flex items-center">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  4% improvement
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Model Performance Metrics</CardTitle>
              <CardDescription>Tracking accuracy, precision, and recall over time</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={modelPerformanceData}
                    margin={{
                      top: 20,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis domain={[0.7, 0.9]} />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="accuracy" stroke="#3b82f6" name="Accuracy" />
                    <Line type="monotone" dataKey="precision" stroke="#10b981" name="Precision" />
                    <Line type="monotone" dataKey="recall" stroke="#8b5cf6" name="Recall" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Confusion Matrix</CardTitle>
                <CardDescription>Model prediction results on test data</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
                  <div className="bg-green-100 p-6 rounded-lg text-center">
                    <p className="text-sm text-gray-600">True Negative</p>
                    <p className="text-2xl font-bold">423</p>
                    <p className="text-xs text-gray-500">Correctly predicted non-defaults</p>
                  </div>
                  <div className="bg-red-100 p-6 rounded-lg text-center">
                    <p className="text-sm text-gray-600">False Positive</p>
                    <p className="text-2xl font-bold">67</p>
                    <p className="text-xs text-gray-500">Incorrectly predicted defaults</p>
                  </div>
                  <div className="bg-red-100 p-6 rounded-lg text-center">
                    <p className="text-sm text-gray-600">False Negative</p>
                    <p className="text-2xl font-bold">43</p>
                    <p className="text-xs text-gray-500">Missed actual defaults</p>
                  </div>
                  <div className="bg-green-100 p-6 rounded-lg text-center">
                    <p className="text-sm text-gray-600">True Positive</p>
                    <p className="text-2xl font-bold">167</p>
                    <p className="text-xs text-gray-500">Correctly predicted defaults</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Model Updates</CardTitle>
                <CardDescription>Recent model version history</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="border-l-2 border-blue-500 pl-4 pb-4">
                    <p className="text-sm font-medium">Version 3.2.1</p>
                    <p className="text-xs text-gray-500">May 15, 2025</p>
                    <p className="text-sm mt-1">
                      Improved feature engineering for credit history variables. Accuracy increased by 1.2%.
                    </p>
                  </div>
                  <div className="border-l-2 border-blue-500 pl-4 pb-4">
                    <p className="text-sm font-medium">Version 3.2.0</p>
                    <p className="text-xs text-gray-500">April 2, 2025</p>
                    <p className="text-sm mt-1">
                      Added new features related to payment history patterns. Recall improved by 2.5%.
                    </p>
                  </div>
                  <div className="border-l-2 border-blue-500 pl-4 pb-4">
                    <p className="text-sm font-medium">Version 3.1.0</p>
                    <p className="text-xs text-gray-500">March 10, 2025</p>
                    <p className="text-sm mt-1">
                      Hyperparameter tuning to reduce false positives. Precision increased by 1.8%.
                    </p>
                  </div>
                  <div className="border-l-2 border-blue-500 pl-4">
                    <p className="text-sm font-medium">Version 3.0.0</p>
                    <p className="text-xs text-gray-500">February 5, 2025</p>
                    <p className="text-sm mt-1">Major model architecture update. Overall accuracy improved by 3.5%.</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="features" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Feature Importance</CardTitle>
              <CardDescription>Relative importance of features in the prediction model</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    layout="vertical"
                    data={featureImportanceData}
                    margin={{
                      top: 20,
                      right: 30,
                      left: 100,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" domain={[0, 0.3]} tickFormatter={(value) => `${(value * 100).toFixed(0)}%`} />
                    <YAxis dataKey="name" type="category" />
                    <Tooltip formatter={(value) => `${(value * 100).toFixed(1)}%`} />
                    <Bar dataKey="importance" fill="#3b82f6" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Credit Score Distribution</CardTitle>
                <CardDescription>Distribution of credit scores among defaulters vs. non-defaulters</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={[
                        { range: "300-400", defaulters: 42, nonDefaulters: 5 },
                        { range: "400-500", defaulters: 35, nonDefaulters: 18 },
                        { range: "500-600", defaulters: 28, nonDefaulters: 45 },
                        { range: "600-700", defaulters: 15, nonDefaulters: 87 },
                        { range: "700-800", defaulters: 8, nonDefaulters: 120 },
                        { range: "800-850", defaulters: 2, nonDefaulters: 45 },
                      ]}
                      margin={{
                        top: 20,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="range" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="defaulters" fill="#ef4444" name="Defaulters" />
                      <Bar dataKey="nonDefaulters" fill="#3b82f6" name="Non-Defaulters" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Debt-to-Income Ratio</CardTitle>
                <CardDescription>Impact of debt-to-income ratio on default probability</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={[
                        { ratio: "0-10%", defaultProb: 0.02 },
                        { ratio: "10-20%", defaultProb: 0.05 },
                        { ratio: "20-30%", defaultProb: 0.08 },
                        { ratio: "30-40%", defaultProb: 0.15 },
                        { ratio: "40-50%", defaultProb: 0.25 },
                        { ratio: "50-60%", defaultProb: 0.4 },
                        { ratio: "60%+", defaultProb: 0.65 },
                      ]}
                      margin={{
                        top: 20,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="ratio" />
                      <YAxis tickFormatter={(value) => `${(value * 100).toFixed(0)}%`} />
                      <Tooltip formatter={(value) => `${(value * 100).toFixed(1)}%`} />
                      <Line type="monotone" dataKey="defaultProb" stroke="#ef4444" name="Default Probability" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Feature Correlation Matrix</CardTitle>
              <CardDescription>Correlation between different features in the model</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4">Feature</th>
                      <th className="text-left py-3 px-4">Credit Score</th>
                      <th className="text-left py-3 px-4">Income</th>
                      <th className="text-left py-3 px-4">Debt-to-Income</th>
                      <th className="text-left py-3 px-4">Loan Amount</th>
                      <th className="text-left py-3 px-4">Employment Years</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b">
                      <td className="py-3 px-4 font-medium">Credit Score</td>
                      <td className="py-3 px-4">1.00</td>
                      <td className="py-3 px-4">0.42</td>
                      <td className="py-3 px-4">-0.65</td>
                      <td className="py-3 px-4">0.18</td>
                      <td className="py-3 px-4">0.37</td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-3 px-4 font-medium">Income</td>
                      <td className="py-3 px-4">0.42</td>
                      <td className="py-3 px-4">1.00</td>
                      <td className="py-3 px-4">-0.48</td>
                      <td className="py-3 px-4">0.56</td>
                      <td className="py-3 px-4">0.52</td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-3 px-4 font-medium">Debt-to-Income</td>
                      <td className="py-3 px-4">-0.65</td>
                      <td className="py-3 px-4">-0.48</td>
                      <td className="py-3 px-4">1.00</td>
                      <td className="py-3 px-4">0.12</td>
                      <td className="py-3 px-4">-0.31</td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-3 px-4 font-medium">Loan Amount</td>
                      <td className="py-3 px-4">0.18</td>
                      <td className="py-3 px-4">0.56</td>
                      <td className="py-3 px-4">0.12</td>
                      <td className="py-3 px-4">1.00</td>
                      <td className="py-3 px-4">0.28</td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-3 px-4 font-medium">Employment Years</td>
                      <td className="py-3 px-4">0.37</td>
                      <td className="py-3 px-4">0.52</td>
                      <td className="py-3 px-4">-0.31</td>
                      <td className="py-3 px-4">0.28</td>
                      <td className="py-3 px-4">1.00</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="predictions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Predictions</CardTitle>
              <CardDescription>Latest loan applications processed by the model</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4">ID</th>
                      <th className="text-left py-3 px-4">Date</th>
                      <th className="text-left py-3 px-4">Amount</th>
                      <th className="text-left py-3 px-4">Term</th>
                      <th className="text-left py-3 px-4">Credit Score</th>
                      <th className="text-left py-3 px-4">Default Probability</th>
                      <th className="text-left py-3 px-4">Prediction</th>
                      <th className="text-left py-3 px-4">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b">
                      <td className="py-3 px-4">APP-7845</td>
                      <td className="py-3 px-4">May 19, 2025</td>
                      <td className="py-3 px-4">$15,000</td>
                      <td className="py-3 px-4">36 months</td>
                      <td className="py-3 px-4">720</td>
                      <td className="py-3 px-4">12%</td>
                      <td className="py-3 px-4">
                        <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Low Risk</span>
                      </td>
                      <td className="py-3 px-4">
                        <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Approved</span>
                      </td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-3 px-4">APP-7844</td>
                      <td className="py-3 px-4">May 19, 2025</td>
                      <td className="py-3 px-4">$30,000</td>
                      <td className="py-3 px-4">60 months</td>
                      <td className="py-3 px-4">680</td>
                      <td className="py-3 px-4">28%</td>
                      <td className="py-3 px-4">
                        <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs">
                          Medium Risk
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs">Review</span>
                      </td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-3 px-4">APP-7843</td>
                      <td className="py-3 px-4">May 18, 2025</td>
                      <td className="py-3 px-4">$5,000</td>
                      <td className="py-3 px-4">24 months</td>
                      <td className="py-3 px-4">750</td>
                      <td className="py-3 px-4">8%</td>
                      <td className="py-3 px-4">
                        <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Low Risk</span>
                      </td>
                      <td className="py-3 px-4">
                        <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Approved</span>
                      </td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-3 px-4">APP-7842</td>
                      <td className="py-3 px-4">May 18, 2025</td>
                      <td className="py-3 px-4">$45,000</td>
                      <td className="py-3 px-4">72 months</td>
                      <td className="py-3 px-4">580</td>
                      <td className="py-3 px-4">72%</td>
                      <td className="py-3 px-4">
                        <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">High Risk</span>
                      </td>
                      <td className="py-3 px-4">
                        <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">Rejected</span>
                      </td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-3 px-4">APP-7841</td>
                      <td className="py-3 px-4">May 18, 2025</td>
                      <td className="py-3 px-4">$20,000</td>
                      <td className="py-3 px-4">48 months</td>
                      <td className="py-3 px-4">710</td>
                      <td className="py-3 px-4">15%</td>
                      <td className="py-3 px-4">
                        <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Low Risk</span>
                      </td>
                      <td className="py-3 px-4">
                        <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Approved</span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Prediction Explanations</CardTitle>
                <CardDescription>Feature importance for individual predictions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <p className="font-medium">APP-7842 (High Risk - 72%)</p>
                      <AlertTriangle className="h-4 w-4 text-red-500" />
                    </div>
                    <div className="space-y-2">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Low Credit Score (580)</span>
                          <span className="font-medium">+35%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-1.5">
                          <div className="bg-red-500 h-1.5 rounded-full" style={{ width: "35%" }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>High Debt-to-Income (58%)</span>
                          <span className="font-medium">+25%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-1.5">
                          <div className="bg-red-500 h-1.5 rounded-full" style={{ width: "25%" }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Previous Default History</span>
                          <span className="font-medium">+12%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-1.5">
                          <div className="bg-red-500 h-1.5 rounded-full" style={{ width: "12%" }}></div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <p className="font-medium">APP-7845 (Low Risk - 12%)</p>
                      <CheckCircle2 className="h-4 w-4 text-green-500" />
                    </div>
                    <div className="space-y-2">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>High Credit Score (720)</span>
                          <span className="font-medium">-18%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-1.5">
                          <div className="bg-green-500 h-1.5 rounded-full" style={{ width: "18%" }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Low Debt-to-Income (22%)</span>
                          <span className="font-medium">-15%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-1.5">
                          <div className="bg-green-500 h-1.5 rounded-full" style={{ width: "15%" }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Stable Employment (7 years)</span>
                          <span className="font-medium">-10%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-1.5">
                          <div className="bg-green-500 h-1.5 rounded-full" style={{ width: "10%" }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Prediction Thresholds</CardTitle>
                <CardDescription>Current risk classification thresholds</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <p className="font-medium mb-2">Risk Classification</p>
                    <div className="h-6 w-full bg-gradient-to-r from-green-500 via-yellow-500 to-red-500 rounded-full relative">
                      <div className="absolute top-6 left-[20%] h-4 border-l border-gray-800"></div>
                      <div className="absolute top-6 left-[60%] h-4 border-l border-gray-800"></div>
                      <div className="absolute top-10 left-[10%] text-xs">Low Risk</div>
                      <div className="absolute top-10 left-[40%] text-xs">Medium Risk</div>
                      <div className="absolute top-10 left-[80%] text-xs">High Risk</div>
                    </div>
                  </div>

                  <div className="pt-8">
                    <p className="font-medium mb-4">Threshold Settings</p>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Low Risk Threshold</span>
                          <span className="font-medium">0% - 20%</span>
                        </div>
                        <p className="text-xs text-gray-500">Automatic approval</p>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Medium Risk Threshold</span>
                          <span className="font-medium">20% - 60%</span>
                        </div>
                        <p className="text-xs text-gray-500">Manual review required</p>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>High Risk Threshold</span>
                          <span className="font-medium">60% - 100%</span>
                        </div>
                        <p className="text-xs text-gray-500">Automatic rejection</p>
                      </div>
                    </div>
                  </div>

                  <div>
                    <Button variant="outline" size="sm" className="w-full">
                      Adjust Thresholds
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
