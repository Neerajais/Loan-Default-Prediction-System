from flask import Flask, request, jsonify, render_template
import pandas as pd
import joblib
import os
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("app.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Load the model
MODEL_PATH = 'model/loan_default_model.pkl'

def load_model():
    try:
        model = joblib.load(MODEL_PATH)
        logger.info("Model loaded successfully")
        return model
    except Exception as e:
        logger.error(f"Error loading model: {str(e)}")
        return None

model = load_model()

# Feature list expected by the model
FEATURES = [
    'income', 'credit_score', 'age', 'loan_amount', 'loan_term', 
    'employment_years', 'debt_to_income', 'home_ownership', 
    'purpose', 'previous_defaults'
]

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get data from request
        data = request.json
        logger.info(f"Received prediction request: {data}")
        
        # Validate input data
        for feature in FEATURES:
            if feature not in data:
                return jsonify({'error': f'Missing feature: {feature}'}), 400
        
        # Create DataFrame with the input data
        input_df = pd.DataFrame([data])
        
        # Add loan_to_income_ratio if model expects it
        if 'loan_to_income_ratio' not in input_df.columns and 'income' in input_df.columns and 'loan_amount' in input_df.columns:
            input_df['loan_to_income_ratio'] = input_df['loan_amount'] / input_df['income']
        
        # Make prediction
        prediction = model.predict(input_df)[0]
        probability = model.predict_proba(input_df)[0, 1]
        
        # Determine risk level
        if probability < 0.2:
            risk_level = "Low"
        elif probability < 0.6:
            risk_level = "Medium"
        else:
            risk_level = "High"
        
        # Identify key risk factors
        risk_factors = []
        if float(input_df['credit_score'][0]) < 670:
            risk_factors.append("Low credit score")
        if float(input_df['debt_to_income'][0]) > 40:
            risk_factors.append("High debt-to-income ratio")
        if input_df['previous_defaults'][0] == 'YES':
            risk_factors.append("Previous defaults")
        if float(input_df['loan_amount'][0]) / float(input_df['income'][0]) > 0.5:
            risk_factors.append("High loan-to-income ratio")
        if float(input_df['employment_years'][0]) < 2:
            risk_factors.append("Short employment history")
        
        # Log the prediction
        logger.info(f"Prediction: {prediction}, Probability: {probability:.4f}, Risk Level: {risk_level}")
        
        # Return prediction result
        result = {
            'prediction': int(prediction),
            'probability': float(probability),
            'risk_level': risk_level,
            'risk_factors': risk_factors
        }
        
        # Log prediction to database (in a real implementation)
        log_prediction(data, result)
        
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"Error making prediction: {str(e)}")
        return jsonify({'error': str(e)}), 500

def log_prediction(input_data, result):
    """
    Log prediction to database for monitoring and auditing
    In a real implementation, this would write to a database
    """
    log_entry = {
        'timestamp': datetime.now().isoformat(),
        'input': input_data,
        'output': result
    }
    logger.info(f"Prediction logged: {log_entry}")
    # In a real implementation:
    # db.predictions.insert_one(log_entry)

@app.route('/model-info', methods=['GET'])
def model_info():
    """Return information about the model"""
    if model is None:
        return jsonify({'error': 'Model not loaded'}), 500
    
    # In a real implementation, this would be retrieved from a database
    model_info = {
        'name': 'Loan Default Predictor v3.2.1',
        'type': 'Gradient Boosting Classifier',
        'accuracy': 0.80,
        'precision': 0.84,
        'recall': 0.82,
        'f1_score': 0.83,
        'last_updated': '2025-05-15',
        'features_used': FEATURES
    }
    
    return jsonify(model_info)

@app.route('/dashboard-data', methods=['GET'])
def dashboard_data():
    """Return data for the dashboard"""
    # In a real implementation, this would be retrieved from a database
    
    dashboard_data = {
        'stats': {
            'default_rate': '8.2%',
            'default_rate_change': '-10%',
            'savings': '$1.2M',
            'model_accuracy': '80%'
        },
        'monthly_defaults': [
            {'month': 'Jan', 'defaults': 12, 'approvals': 120},
            {'month': 'Feb', 'defaults': 19, 'approvals': 132},
            {'month': 'Mar', 'defaults': 15, 'approvals': 99},
            {'month': 'Apr', 'defaults': 8, 'approvals': 85},
            {'month': 'May', 'defaults': 10, 'approvals': 91},
            {'month': 'Jun', 'defaults': 14, 'approvals': 105},
            {'month': 'Jul', 'defaults': 12, 'approvals': 118},
            {'month': 'Aug', 'defaults': 18, 'approvals': 110},
            {'month': 'Sep', 'defaults': 15, 'approvals': 113},
            {'month': 'Oct', 'defaults': 11, 'approvals': 129},
            {'month': 'Nov', 'defaults': 9, 'approvals': 138},
            {'month': 'Dec', 'defaults': 7, 'approvals': 142}
        ],
        'risk_distribution': [
            {'level': 'Low Risk', 'percentage': 65},
            {'level': 'Medium Risk', 'percentage': 25},
            {'level': 'High Risk', 'percentage': 10}
        ],
        'feature_importance': [
            {'feature': 'Credit Score', 'importance': 0.28},
            {'feature': 'Debt-to-Income', 'importance': 0.22},
            {'feature': 'Income', 'importance': 0.18},
            {'feature': 'Loan Amount', 'importance': 0.12},
            {'feature': 'Previous Defaults', 'importance': 0.10},
            {'feature': 'Employment Years', 'importance': 0.06},
            {'feature': 'Loan Purpose', 'importance': 0.04}
        ]
    }
    
    return jsonify(dashboard_data)

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
