import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  // In a real implementation, this would fetch actual model metadata from a database
  // For this demo, we'll return static information

  const modelInfo = {
    name: "Loan Default Predictor v3.2.1",
    type: "Gradient Boosting Classifier",
    lastUpdated: "2025-05-15",
    metrics: {
      accuracy: 0.8,
      precision: 0.84,
      recall: 0.82,
      f1Score: 0.83,
      auc: 0.87,
    },
    features: [
      { name: "Credit Score", importance: 0.28 },
      { name: "Debt-to-Income", importance: 0.22 },
      { name: "Income", importance: 0.18 },
      { name: "Loan Amount", importance: 0.12 },
      { name: "Previous Defaults", importance: 0.1 },
      { name: "Employment Years", importance: 0.06 },
      { name: "Loan Purpose", importance: 0.04 },
    ],
    performanceHistory: [
      { version: "3.2.1", date: "2025-05-15", accuracy: 0.8 },
      { version: "3.2.0", date: "2025-04-02", accuracy: 0.79 },
      { version: "3.1.0", date: "2025-03-10", accuracy: 0.78 },
      { version: "3.0.0", date: "2025-02-05", accuracy: 0.76 },
    ],
    businessImpact: {
      defaultReduction: "10%",
      costSavings: "$1.2M",
      processingEfficiency: "15%",
    },
  }

  return NextResponse.json(modelInfo)
}
