import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  // In a real implementation, this would fetch actual dashboard data from a database
  // For this demo, we'll return static mock data

  const dashboardData = {
    stats: {
      defaultRate: "8.2%",
      defaultRateChange: "-10%",
      savings: "$1.2M",
      savingsChange: "+15%",
      modelAccuracy: "80%",
      modelAccuracyChange: "+2%",
      activeLoans: 1482,
      activeLoansChange: "+8%",
    },

    monthlyDefaultData: [
      { name: "Jan", defaults: 12, approvals: 120 },
      { name: "Feb", defaults: 19, approvals: 132 },
      { name: "Mar", defaults: 15, approvals: 99 },
      { name: "Apr", defaults: 8, approvals: 85 },
      { name: "May", defaults: 10, approvals: 91 },
      { name: "Jun", defaults: 14, approvals: 105 },
      { name: "Jul", defaults: 12, approvals: 118 },
      { name: "Aug", defaults: 18, approvals: 110 },
      { name: "Sep", defaults: 15, approvals: 113 },
      { name: "Oct", defaults: 11, approvals: 129 },
      { name: "Nov", defaults: 9, approvals: 138 },
      { name: "Dec", defaults: 7, approvals: 142 },
    ],

    riskDistributionData: [
      { name: "Low Risk", value: 65 },
      { name: "Medium Risk", value: 25 },
      { name: "High Risk", value: 10 },
    ],

    featureImportanceData: [
      { name: "Credit Score", importance: 0.28 },
      { name: "Debt-to-Income", importance: 0.22 },
      { name: "Income", importance: 0.18 },
      { name: "Loan Amount", importance: 0.12 },
      { name: "Previous Defaults", importance: 0.1 },
      { name: "Employment Years", importance: 0.06 },
      { name: "Loan Purpose", importance: 0.04 },
    ],

    modelPerformanceData: [
      { name: "Jan", accuracy: 0.78, precision: 0.76, recall: 0.72 },
      { name: "Feb", accuracy: 0.79, precision: 0.77, recall: 0.73 },
      { name: "Mar", accuracy: 0.79, precision: 0.78, recall: 0.74 },
      { name: "Apr", accuracy: 0.8, precision: 0.79, recall: 0.75 },
      { name: "May", accuracy: 0.81, precision: 0.8, recall: 0.76 },
      { name: "Jun", accuracy: 0.81, precision: 0.8, recall: 0.77 },
      { name: "Jul", accuracy: 0.82, precision: 0.81, recall: 0.78 },
      { name: "Aug", accuracy: 0.82, precision: 0.81, recall: 0.79 },
      { name: "Sep", accuracy: 0.83, precision: 0.82, recall: 0.8 },
      { name: "Oct", accuracy: 0.83, precision: 0.82, recall: 0.8 },
      { name: "Nov", accuracy: 0.84, precision: 0.83, recall: 0.81 },
      { name: "Dec", accuracy: 0.85, precision: 0.84, recall: 0.82 },
    ],

    highRiskAlerts: [
      {
        id: "APP-7829",
        date: "May 18, 2025",
        amount: "$35,000",
        riskScore: "High (87%)",
        keyFactors: "Low credit score, Previous defaults",
        status: "Review",
      },
      {
        id: "APP-7830",
        date: "May 17, 2025",
        amount: "$50,000",
        riskScore: "High (92%)",
        keyFactors: "High debt-to-income ratio, Short employment",
        status: "Rejected",
      },
      {
        id: "APP-7835",
        date: "May 16, 2025",
        amount: "$25,000",
        riskScore: "High (81%)",
        keyFactors: "Previous defaults, Low income",
        status: "Review",
      },
    ],

    recentPredictions: [
      {
        id: "APP-7845",
        date: "May 19, 2025",
        amount: "$15,000",
        term: "36 months",
        creditScore: "720",
        defaultProbability: "12%",
        prediction: "Low Risk",
        status: "Approved",
      },
      {
        id: "APP-7844",
        date: "May 19, 2025",
        amount: "$30,000",
        term: "60 months",
        creditScore: "680",
        defaultProbability: "28%",
        prediction: "Medium Risk",
        status: "Review",
      },
      {
        id: "APP-7843",
        date: "May 18, 2025",
        amount: "$5,000",
        term: "24 months",
        creditScore: "750",
        defaultProbability: "8%",
        prediction: "Low Risk",
        status: "Approved",
      },
      {
        id: "APP-7842",
        date: "May 18, 2025",
        amount: "$45,000",
        term: "72 months",
        creditScore: "580",
        defaultProbability: "72%",
        prediction: "High Risk",
        status: "Rejected",
      },
      {
        id: "APP-7841",
        date: "May 18, 2025",
        amount: "$20,000",
        term: "48 months",
        creditScore: "710",
        defaultProbability: "15%",
        prediction: "Low Risk",
        status: "Approved",
      },
    ],
  }

  return NextResponse.json(dashboardData)
}
