"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, CheckCircle2 } from "lucide-react"

const formSchema = z.object({
  income: z.string().min(1, { message: "Income is required" }),
  creditScore: z.string().min(1, { message: "Credit score is required" }),
  age: z.string().min(1, { message: "Age is required" }),
  loanAmount: z.string().min(1, { message: "Loan amount is required" }),
  loanTerm: z.string().min(1, { message: "Loan term is required" }),
  employmentYears: z.string().min(1, { message: "Employment years is required" }),
  homeOwnership: z.string().min(1, { message: "Home ownership status is required" }),
  purpose: z.string().min(1, { message: "Loan purpose is required" }),
  debtToIncome: z.coerce.number().min(0).max(100),
  previousDefaults: z.string().min(1, { message: "Previous defaults information is required" }),
})

export default function PredictPage() {
  const [prediction, setPrediction] = useState<null | { result: boolean; probability: number }>(null)
  const [isLoading, setIsLoading] = useState(false)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      income: "",
      creditScore: "",
      age: "",
      loanAmount: "",
      loanTerm: "",
      employmentYears: "",
      homeOwnership: "RENT",
      purpose: "PERSONAL",
      debtToIncome: 30,
      previousDefaults: "NO",
    },
  })

  function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true)

    // Simulate API call to prediction model
    setTimeout(() => {
      // Mock prediction result
      const mockProbability = Math.random()
      setPrediction({
        result: mockProbability > 0.5,
        probability: mockProbability * 100,
      })
      setIsLoading(false)
    }, 1500)
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-8 text-center">Loan Default Prediction</h1>

      <div className="grid md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Enter Loan Details</CardTitle>
            <CardDescription>Fill in the applicant information to predict loan default risk</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="income"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Annual Income ($)</FormLabel>
                        <FormControl>
                          <Input placeholder="60000" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="creditScore"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Credit Score</FormLabel>
                        <FormControl>
                          <Input placeholder="720" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="age"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Age</FormLabel>
                        <FormControl>
                          <Input placeholder="35" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="loanAmount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Loan Amount ($)</FormLabel>
                        <FormControl>
                          <Input placeholder="25000" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="loanTerm"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Loan Term (months)</FormLabel>
                        <FormControl>
                          <Input placeholder="36" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="employmentYears"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Years Employed</FormLabel>
                        <FormControl>
                          <Input placeholder="5" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="homeOwnership"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Home Ownership</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select home ownership status" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="OWN">Own</SelectItem>
                            <SelectItem value="MORTGAGE">Mortgage</SelectItem>
                            <SelectItem value="RENT">Rent</SelectItem>
                            <SelectItem value="OTHER">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="purpose"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Loan Purpose</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select loan purpose" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="PERSONAL">Personal</SelectItem>
                            <SelectItem value="EDUCATION">Education</SelectItem>
                            <SelectItem value="MEDICAL">Medical</SelectItem>
                            <SelectItem value="VENTURE">Business Venture</SelectItem>
                            <SelectItem value="HOMEIMPROVEMENT">Home Improvement</SelectItem>
                            <SelectItem value="DEBTCONSOLIDATION">Debt Consolidation</SelectItem>
                            <SelectItem value="OTHER">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="debtToIncome"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Debt-to-Income Ratio (%): {field.value}</FormLabel>
                      <FormControl>
                        <Slider
                          min={0}
                          max={100}
                          step={1}
                          defaultValue={[field.value]}
                          onValueChange={(vals) => field.onChange(vals[0])}
                        />
                      </FormControl>
                      <FormDescription>The percentage of monthly income that goes toward paying debts</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="previousDefaults"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Previous Defaults</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Any previous defaults?" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="NO">No</SelectItem>
                          <SelectItem value="YES">Yes</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? "Processing..." : "Predict Default Risk"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        <div>
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Prediction Result</CardTitle>
              <CardDescription>Our model prediction based on the provided information</CardDescription>
            </CardHeader>
            <CardContent>
              {prediction ? (
                <div className="space-y-4">
                  <Alert
                    variant={prediction.result ? "destructive" : "default"}
                    className={prediction.result ? "bg-red-50" : "bg-green-50"}
                  >
                    <div className="flex items-center gap-2">
                      {prediction.result ? (
                        <AlertCircle className="h-5 w-5 text-red-600" />
                      ) : (
                        <CheckCircle2 className="h-5 w-5 text-green-600" />
                      )}
                      <AlertTitle className={prediction.result ? "text-red-600" : "text-green-600"}>
                        {prediction.result ? "High Risk of Default" : "Low Risk of Default"}
                      </AlertTitle>
                    </div>
                    <AlertDescription className="mt-2">
                      {prediction.result
                        ? "This applicant has a high probability of defaulting on the loan."
                        : "This applicant has a low probability of defaulting on the loan."}
                    </AlertDescription>
                  </Alert>

                  <div className="mt-4">
                    <p className="text-sm font-medium mb-1">Default Probability</p>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div
                        className={`h-2.5 rounded-full ${prediction.result ? "bg-red-600" : "bg-green-600"}`}
                        style={{ width: `${prediction.probability}%` }}
                      ></div>
                    </div>
                    <p className="text-right text-sm mt-1">{prediction.probability.toFixed(1)}%</p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <p>Fill in the form and submit to see prediction results</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Model Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium">Model Accuracy</h3>
                  <p className="text-gray-600">80% accuracy on test data</p>
                </div>
                <div>
                  <h3 className="font-medium">Features Used</h3>
                  <p className="text-gray-600">
                    15+ features including income, credit score, loan details, and payment history
                  </p>
                </div>
                <div>
                  <h3 className="font-medium">Last Updated</h3>
                  <p className="text-gray-600">May 15, 2025</p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <p className="text-sm text-gray-500">
                This model is continuously monitored and updated to maintain accuracy and relevance.
              </p>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}
