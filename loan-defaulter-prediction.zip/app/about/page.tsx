import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart3,
  Brain,
  Code,
  Database,
  FileText,
  FlaskRoundIcon as Flask,
  LineChart,
  Shield,
  Workflow,
} from "lucide-react"

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-2">About the Loan Defaulter Prediction System</h1>
        <p className="text-gray-500 mb-8">Learn about our machine learning solution for minimizing financial risk</p>

        <Tabs defaultValue="overview" className="space-y-8">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="technical">Technical Details</TabsTrigger>
            <TabsTrigger value="results">Results</TabsTrigger>
            <TabsTrigger value="team">Team</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="prose max-w-none">
              <h2>Project Overview</h2>
              <p>
                The Loan Defaulter Prediction System is an advanced machine learning solution designed to minimize
                financial risk for banks and lending institutions. By analyzing a comprehensive set of borrower
                attributes, the system can predict with high accuracy the likelihood of a loan default.
              </p>

              <h3>Key Objectives</h3>
              <ul>
                <li>Reduce financial losses due to loan defaults</li>
                <li>Improve decision-making in the loan approval process</li>
                <li>Provide data-driven insights into risk factors</li>
                <li>Enable real-time risk assessment for loan applications</li>
              </ul>

              <h3>Business Impact</h3>
              <p>
                Our system has achieved a 10% reduction in loan defaulters, saving approximately $1.2M in potential
                losses for our client institutions. By identifying high-risk applicants early in the process, lenders
                can make more informed decisions about loan approvals, terms, and interest rates.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
              <Card>
                <CardHeader className="flex flex-row items-center space-y-0 pb-2">
                  <Brain className="h-4 w-4 text-blue-600 mr-2" />
                  <CardTitle className="text-sm font-medium">ML Models</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-xs">
                    Built with advanced machine learning algorithms to achieve 80% prediction accuracy
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center space-y-0 pb-2">
                  <Database className="h-4 w-4 text-blue-600 mr-2" />
                  <CardTitle className="text-sm font-medium">Data Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-xs">
                    Comprehensive data preprocessing and exploratory data analysis
                  </CardDescription>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center space-y-0 pb-2">
                  <Flask className="h-4 w-4 text-blue-600 mr-2" />
                  <CardTitle className="text-sm font-medium">Deployment</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-xs">
                    Deployed using Flask for real-time loan risk assessment
                  </CardDescription>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="technical" className="space-y-6">
            <div className="prose max-w-none">
              <h2>Technical Implementation</h2>
              <p>
                Our loan defaulter prediction system employs a sophisticated technical architecture that combines data
                science, machine learning, and software engineering best practices.
              </p>

              <h3>Data Preprocessing</h3>
              <p>The system processes raw loan application data through several stages:</p>
              <ul>
                <li>Missing value imputation using statistical methods</li>
                <li>Outlier detection and treatment</li>
                <li>Feature scaling and normalization</li>
                <li>Categorical variable encoding</li>
                <li>Feature engineering to create derived variables</li>
              </ul>

              <h3>Machine Learning Models</h3>
              <p>We implemented and compared several machine learning algorithms:</p>
              <ul>
                <li>Gradient Boosting Classifier</li>
                <li>Random Forest</li>
                <li>Logistic Regression</li>
                <li>Neural Networks</li>
              </ul>
              <p>
                After extensive testing, the Gradient Boosting Classifier was selected as the primary model due to its
                superior performance in both accuracy and interpretability.
              </p>

              <h3>Hyperparameter Tuning</h3>
              <p>
                We employed grid search with cross-validation to optimize model parameters, resulting in significant
                improvements in model performance.
              </p>

              <h3>Deployment Architecture</h3>
              <p>
                The system is deployed using a Flask API that enables real-time predictions. The architecture includes:
              </p>
              <ul>
                <li>RESTful API endpoints for prediction requests</li>
                <li>Model versioning and tracking</li>
                <li>Monitoring and logging infrastructure</li>
                <li>Scheduled retraining pipeline</li>
              </ul>
            </div>

            <div className="mt-8">
              <Card>
                <CardHeader>
                  <CardTitle>Technology Stack</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="flex flex-col items-center p-4 border rounded-lg">
                      <Code className="h-8 w-8 text-blue-600 mb-2" />
                      <p className="text-sm font-medium">Python</p>
                    </div>
                    <div className="flex flex-col items-center p-4 border rounded-lg">
                      <Brain className="h-8 w-8 text-blue-600 mb-2" />
                      <p className="text-sm font-medium">Scikit-learn</p>
                    </div>
                    <div className="flex flex-col items-center p-4 border rounded-lg">
                      <Database className="h-8 w-8 text-blue-600 mb-2" />
                      <p className="text-sm font-medium">Pandas</p>
                    </div>
                    <div className="flex flex-col items-center p-4 border rounded-lg">
                      <LineChart className="h-8 w-8 text-blue-600 mb-2" />
                      <p className="text-sm font-medium">Matplotlib</p>
                    </div>
                    <div className="flex flex-col items-center p-4 border rounded-lg">
                      <BarChart3 className="h-8 w-8 text-blue-600 mb-2" />
                      <p className="text-sm font-medium">Seaborn</p>
                    </div>
                    <div className="flex flex-col items-center p-4 border rounded-lg">
                      <Flask className="h-8 w-8 text-blue-600 mb-2" />
                      <p className="text-sm font-medium">Flask</p>
                    </div>
                    <div className="flex flex-col items-center p-4 border rounded-lg">
                      <Shield className="h-8 w-8 text-blue-600 mb-2" />
                      <p className="text-sm font-medium">NumPy</p>
                    </div>
                    <div className="flex flex-col items-center p-4 border rounded-lg">
                      <Workflow className="h-8 w-8 text-blue-600 mb-2" />
                      <p className="text-sm font-medium">XGBoost</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="results" className="space-y-6">
            <div className="prose max-w-none">
              <h2>Project Results</h2>
              <p>
                The Loan Defaulter Prediction System has delivered significant results for our client institutions,
                demonstrating the value of machine learning in financial risk management.
              </p>

              <h3>Model Performance</h3>
              <p>Our final model achieved the following metrics on the test dataset:</p>
              <ul>
                <li>
                  <strong>Accuracy:</strong> 80%
                </li>
                <li>
                  <strong>Precision:</strong> 84%
                </li>
                <li>
                  <strong>Recall:</strong> 82%
                </li>
                <li>
                  <strong>F1 Score:</strong> 83%
                </li>
                <li>
                  <strong>AUC-ROC:</strong> 0.87
                </li>
              </ul>

              <h3>Business Impact</h3>
              <p>The implementation of our system has resulted in:</p>
              <ul>
                <li>10% reduction in loan defaulters</li>
                <li>$1.2M in potential loss savings</li>
                <li>15% improvement in loan approval efficiency</li>
                <li>8% increase in customer satisfaction due to faster processing</li>
              </ul>

              <h3>Key Insights</h3>
              <p>Through our analysis, we discovered several important insights about loan default patterns:</p>
              <ul>
                <li>Credit score is the strongest predictor of default risk</li>
                <li>Debt-to-income ratio above 40% significantly increases default probability</li>
                <li>Loan purpose categories have varying risk profiles</li>
                <li>Employment stability is a stronger predictor than income level</li>
              </ul>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
              <Card>
                <CardHeader>
                  <CardTitle>Model Performance Metrics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <p className="text-sm font-medium mb-1">Accuracy</p>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: "80%" }}></div>
                      </div>
                      <div className="flex justify-between text-xs mt-1">
                        <span>0%</span>
                        <span>80%</span>
                        <span>100%</span>
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-1">Precision</p>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: "84%" }}></div>
                      </div>
                      <div className="flex justify-between text-xs mt-1">
                        <span>0%</span>
                        <span>84%</span>
                        <span>100%</span>
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-1">Recall</p>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: "82%" }}></div>
                      </div>
                      <div className="flex justify-between text-xs mt-1">
                        <span>0%</span>
                        <span>82%</span>
                        <span>100%</span>
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-1">F1 Score</p>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: "83%" }}></div>
                      </div>
                      <div className="flex justify-between text-xs mt-1">
                        <span>0%</span>
                        <span>83%</span>
                        <span>100%</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Business Impact</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="text-sm font-medium">Default Reduction</p>
                        <p className="text-xs text-gray-500">Year-over-year improvement</p>
                      </div>
                      <p className="text-xl font-bold text-green-600">10%</p>
                    </div>

                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="text-sm font-medium">Cost Savings</p>
                        <p className="text-xs text-gray-500">Potential loss prevention</p>
                      </div>
                      <p className="text-xl font-bold text-green-600">$1.2M</p>
                    </div>

                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="text-sm font-medium">Processing Efficiency</p>
                        <p className="text-xs text-gray-500">Improvement in approval workflow</p>
                      </div>
                      <p className="text-xl font-bold text-green-600">15%</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="team" className="space-y-6">
            <div className="prose max-w-none">
              <h2>Our Team</h2>
              <p>
                The Loan Defaulter Prediction System was developed by a multidisciplinary team of data scientists,
                machine learning engineers, and domain experts in finance.
              </p>

              <h3>Team Structure</h3>
              <p>Our project team consisted of:</p>
              <ul>
                <li>2 Data Scientists specializing in financial modeling</li>
                <li>1 Machine Learning Engineer</li>
                <li>1 Full-Stack Developer</li>
                <li>1 Financial Risk Analyst</li>
                <li>1 Project Manager</li>
              </ul>

              <h3>Development Process</h3>
              <p>
                We followed an agile development methodology with two-week sprints, regular stakeholder reviews, and
                continuous integration of feedback. The project was completed over a six-month period, with ongoing
                maintenance and model updates.
              </p>

              <h3>Continuous Improvement</h3>
              <p>Our team maintains the system with:</p>
              <ul>
                <li>Monthly model performance reviews</li>
                <li>Quarterly model retraining with new data</li>
                <li>Feature engineering experiments to improve accuracy</li>
                <li>Regular updates to the deployment infrastructure</li>
              </ul>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
              <Card>
                <CardHeader>
                  <CardTitle>Data Science</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start">
                      <span className="bg-blue-100 text-blue-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded">
                        Lead
                      </span>
                      <span>Dr. Sarah Chen - Financial ML Specialist</span>
                    </li>
                    <li className="flex items-start">
                      <span className="bg-blue-100 text-blue-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded">
                        Member
                      </span>
                      <span>Michael Rodriguez - Data Scientist</span>
                    </li>
                    <li className="flex items-start">
                      <span className="bg-blue-100 text-blue-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded">
                        Member
                      </span>
                      <span>Priya Sharma - ML Engineer</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Engineering</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start">
                      <span className="bg-green-100 text-green-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded">
                        Lead
                      </span>
                      <span>James Wilson - Full-Stack Developer</span>
                    </li>
                    <li className="flex items-start">
                      <span className="bg-green-100 text-green-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded">
                        Member
                      </span>
                      <span>Aisha Johnson - Backend Engineer</span>
                    </li>
                    <li className="flex items-start">
                      <span className="bg-green-100 text-green-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded">
                        Member
                      </span>
                      <span>David Park - DevOps Engineer</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Domain Experts</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start">
                      <span className="bg-purple-100 text-purple-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded">
                        Lead
                      </span>
                      <span>Robert Chang - Financial Risk Analyst</span>
                    </li>
                    <li className="flex items-start">
                      <span className="bg-purple-100 text-purple-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded">
                        Member
                      </span>
                      <span>Emma Thompson - Credit Specialist</span>
                    </li>
                    <li className="flex items-start">
                      <span className="bg-purple-100 text-purple-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded">
                        Member
                      </span>
                      <span>Carlos Mendez - Banking Consultant</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Contact Us</CardTitle>
                <CardDescription>
                  Interested in learning more about our loan defaulter prediction system?
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <p className="text-sm font-medium mb-1">Email</p>
                    <p className="text-sm">contact@loansafe.ai</p>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium mb-1">Phone</p>
                    <p className="text-sm">+1 (555) 123-4567</p>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium mb-1">Documentation</p>
                    <Link href="#" className="text-sm text-blue-600 hover:underline">
                      <FileText className="h-4 w-4 inline mr-1" />
                      Technical Whitepaper
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
